#! /bin/bash 
# Last edited on 2015-10-03 14:19:55 by stolfilocal

wdir="http://www.dainf.ct.utfpr.edu.br/~rminetto/projects/slicing/stl_models"

# Got:
# wget -nv "${wdir}/01.bottle.stl"   #  61K     
# wget -nv "${wdir}/02.chassis.stl"  #  151K     
# wget -nv "${wdir}/03.mouse.stl"    #  287K     
# wget -nv "${wdir}/04.liver.stl"    #  1.8M     
# wget -nv "${wdir}/05.femur.stl"    #  2.0M     
# wget -nv "${wdir}/06.eiffel.stl"   #  6.3M     
# wget -nv "${wdir}/07.pump.stl"     #  8.5M     
# wget -nv "${wdir}/08.bunny.stl"    #  13M     
# wget -nv "${wdir}/09.stick.stl"    #  20M     

# Later:
# wget -nv "${wdir}/10.demon.stl"    #  45M     
# wget -nv "${wdir}/11.rider.stl"    #  61M     
# wget -nv "${wdir}/12.sphere.stl"   #  146M     
# wget -nv "${wdir}/13.soldier.stl"  #  162M     
# wget -nv "${wdir}/14.warrior.stl"  #  422M     
# wget -nv "${wdir}/15.robot.stl"    #  585M     
     
# Failed:
# wget -nv "${wdir}/16.skull.stl"    #  795M     
