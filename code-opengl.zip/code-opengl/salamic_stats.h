/* Statistics gathering tools. */
/* Last edited on 2015-09-26 20:02:49 by stolfilocal */

#ifndef salamic_stats_H
#define salamic_stats_H

#define _GNU_SOURCE
#include <stdio.h>

typedef struct salamic_stats_t
  { double tslice;  /* Slicing time (seconds). */
    double tclose;  /* Polygon closing time (seconds). */
  } salamic_stats_t;
  /* Statistics about the slicing algorithm. */


void salamic_stats_clear(salamic_stats_t *st);
  /* Clears the statistics {st}. */

void salamic_stats_print(FILE *wr, salamic_stats_t *st);
  /* Prints the statistics {st} to {wr}. */

#endif
