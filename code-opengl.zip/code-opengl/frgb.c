/* See frgb.h */
/* Last edited on 2004-11-05 22:41:10 by stolfi */ 

#include "frgb.h"

