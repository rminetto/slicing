#define PROG_NAME "Bentley-Ottmann"
#define PROG_DESC "Sweep line algorithm to compute all crossings in a set of line segments."
#define PROG_VERS "1.0"

#define salamic_C_COPYRIGHT \
  "Copyright © 2015 by Federal Technological Universioty of Parana (UTFPR) and State University of Campinas (UNICAMP)"

#define stringify(x) strngf(x)
#define strngf(x) #x

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <math.h>

#include <bool.h>
#include <vec.h>
#include <argparser.h>
#include <affirm.h>

#include <stmesh.h>
#include <stmesh_STL.h>
#include <stmesh_section.h>

#include <salamic_planes.h>
#include <salamic_stats.h>
#include <salamic_slicer.h>
#include <salamic_closer.h>
/* #include <salamic_xml.h> */
/* #include <salamic_graphics.h> */

/* INTERNAL PROTOTYPES */

int main(int argc, char **argv);
  /* Main program. */

/* IMPLEMENTATIONS */

typedef int boolean;
typedef int32_t TYPE1;
typedef int64_t TYPE2;
//typedef int32_t TYPE2;
//typedef TYPE1 int32_t;
//typedef TYPE2 int64_t;

typedef struct _point {
   TYPE1 x;
   TYPE1 y;
} point_t;

typedef struct _intersect {
   TYPE1 x;
   TYPE1 xexact;
   TYPE1 y;
   TYPE1 yexact;
   TYPE2 quo;
   TYPE2 rem;
} intersect_t;

typedef struct _segment {
   point_t p1;
   point_t p2;
} segment_t;

TYPE2 determinant (TYPE1 a, TYPE1 b, TYPE1 c, TYPE1 d) {
   return ((a * d) - (b * c));
}


boolean intersect_segments (segment_t *s1, segment_t *s2, intersect_t *it) {

   TYPE2 det1, det2;

   TYPE1 dx1 = s1->p1.x - s1->p2.x;
   TYPE1 dy1 = s1->p1.y - s1->p2.y;

   TYPE1 dx2 = s2->p1.x - s2->p2.x;
   TYPE1 dy2 = s2->p1.y - s2->p2.y;

   printf("Diferenca: %lld %lld %lld %lld\n", dx1, dy1, dx2, dy2);

   det1 = determinant (dx1, dy1, dx2, dy2); //den_det
   
   det2 = determinant (dx2, dy2, s2->p1.x - s1->p1.x, s2->p1.y - s1->p1.y);  //R

   if (det1 < 0) {
      if (det1 >= det2) { return FALSE; }
   } else {
      if (det1 <= det2) { return FALSE; }
   }

   det2 = determinant (dy1, dx1, s1->p1.y - s2->p1.y, s1->p1.x - s2->p1.x);  //R

   if (det1 < 0) {
      if (det1 >= det2) { return FALSE; }
   } else {
      if (det1 <= det2) { return FALSE; }
   }

   /* We now know that the two lines should intersect within range. */

   TYPE2 a_det = determinant (s1->p1.x, s1->p1.y, s1->p2.x, s1->p2.y);
   TYPE2 b_det = determinant (s2->p1.x, s2->p1.y, s2->p2.x, s2->p2.y);

   it->quo = determinant (a_det, dx1, b_det, dx2); 
   it->rem = det1;

   if (it->quo == it->rem) { return FALSE; }

   it->xexact = TRUE;

   if (it->rem != 0) {
      if ( (det1 < 0) ^ (it->rem < 0)) {
         it->rem = -it->rem;
      }
      it->rem = it->rem * 2;
      if (it->rem >= det1) {
         it->quo = it->quo + (it->quo < 0 ? -1 : 1);
      } else {
         it->xexact = FALSE;
      }
   }
   it->x = it->quo;
 
   it->quo = determinant (a_det, dy1, b_det, dy2); 
   it->rem = det1;
   
   if (it->quo == it->rem) { return FALSE; }
   
   it->yexact = TRUE;

   if (it->rem != 0) {
      if ( (det1 < 0) ^ (it->rem < 0)) {
         it->rem = -it->rem;
      }
      it->rem = it->rem * 2;
      if (it->rem >= det1) {
         it->quo = it->quo + (it->quo < 0 ? -1 : 1);
      } else {
         it->yexact = FALSE;
      }
   }
   it->y = it->quo;
   return TRUE;
} 

int main(int argc, char **argv)
  {
    printf("%d %d\n", 2, 2<<2);
    int bits = 16;
    segment_t s1 = {{3<<bits,6<<bits},{16<<bits,1<<bits}};
    segment_t s2 = {{5<<bits,3<<bits},{11<<bits,5<<bits}};
    //segment_t s2 = {{5,1},{9,2}};
    intersect_t it;
    if (intersect_segments (&s1, &s2, &it)) {
       printf("Intersecção em (%lld,%lld)\n", (long long int)it.x, (long long int)it.y);
    }
    else {
       printf("Pontos sem intersecção!\n");
    }
    
    return 0;
  }


