#define PROG_NAME "Bentley-Ottmann"
#define PROG_DESC "Sweep line algorithm to compute all crossings in a set of line segments."
#define PROG_VERS "1.0"

#define salamic_C_COPYRIGHT \
  "Copyright © 2015 by Federal Technological Universioty of Parana (UTFPR) and State University of Campinas (UNICAMP)"

#define stringify(x) strngf(x)
#define strngf(x) #x

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <math.h>

#include <bool.h>
#include <vec.h>
#include <argparser.h>
#include <affirm.h>

#include <stmesh.h>
#include <stmesh_STL.h>
#include <stmesh_section.h>

#include <salamic_planes.h>
#include <salamic_stats.h>
#include <salamic_slicer.h>
#include <salamic_closer.h>
/* #include <salamic_xml.h> */
/* #include <salamic_graphics.h> */

/* INTERNAL PROTOTYPES */

int main(int argc, char **argv);
  /* Main program. */

/* IMPLEMENTATIONS */

typedef int cairo_bool_t;

typedef uint64_t cairo_uint64_t;
typedef int64_t  cairo_int64_t;
typedef int32_t  cairo_fixed_t;

typedef struct _cairo_quorem64 {
    cairo_int64_t       quo;
    cairo_int64_t       rem;
} cairo_quorem64_t;

typedef struct _cairo_bo_intersect_ordinate {
    int32_t ordinate;
    enum { EXACT, INEXACT } exactness;
} cairo_bo_intersect_ordinate_t;

typedef struct _cairo_bo_intersect_point {
    cairo_bo_intersect_ordinate_t x;
    cairo_bo_intersect_ordinate_t y;
} cairo_bo_intersect_point_t;

typedef struct _cairo_point {
    cairo_fixed_t x;
    cairo_fixed_t y;
} cairo_point_t;

typedef struct _cairo_line {
    cairo_point_t p1;
    cairo_point_t p2;
} cairo_line_t, cairo_box_t;

typedef struct _cairo_edge {
    cairo_line_t line;
    int top, bottom;
    int dir;
} cairo_edge_t;

/*typedef struct cairo_uint128 {
    cairo_uint64_t lo, hi;
} cairo_uint128_t, cairo_int128_t, int128_t;*/

typedef unsigned uint128_t __attribute__ ((mode (TI)));
typedef unsigned int128_t __attribute__ ((mode (TI)));
typedef unsigned cairo_uint128_t __attribute__ ((mode (TI)));
typedef unsigned cairo_int128_t __attribute__ ((mode (TI)));

typedef cairo_point_t cairo_bo_point32_t;
typedef struct _cairo_bo_edge cairo_bo_edge_t;
typedef struct _cairo_bo_trap cairo_bo_trap_t;

struct _cairo_bo_trap {
    cairo_bo_edge_t *right;
    int32_t top;
};

struct _cairo_bo_edge {
    cairo_edge_t edge;
    cairo_bo_edge_t *prev;
    cairo_bo_edge_t *next;
    cairo_bo_trap_t deferred_trap;
};

#define _cairo_int64_sub(a,b) ((a) - (b))
#define _cairo_int64_negative(a) ((a) < 0)
#define _cairo_int64_lt(a,b) ((a) < (b))
#define _cairo_int32x32_64_mul(a,b) ((int64_t) (a) * (b))
#define _cairo_int64_add(a,b) ((a) + (b))
#define _cairo_int64_is_zero(a) ((a) == 0)
#define _cairo_int64_gt(a,b) _cairo_int64_lt(b,a)
#define _cairo_int64_ge(a,b) (!_cairo_int64_lt(a,b))
#define _cairo_int64_mul(a,b) ((a) * (b))
#define _cairo_int64_eq(a,b) ((a) == (b))
#define _cairo_int64_le(a,b) (!_cairo_int64_gt(a,b))
#define _cairo_int64_negate(a) (-(a))
//cairo_int128_t I _cairo_int64x64_128_mul (cairo_int64_t a, cairo_int64_t b);
#define _cairo_int128_sub(a,b) ((a) - (b))
#define _cairo_int64x64_128_mul(a,b) ((int128_t) (a) * (b))
#define _cairo_int32_to_int64(i) ((int64_t) (i))
#define _cairo_int64x32_128_mul(a, b) _cairo_int64x64_128_mul(a, _cairo_int32_to_int64(b))

cairo_quorem64_t cairo_int_96by64_32x64_divrem (cairo_int128_t num,
                                cairo_int64_t  den); 

static inline cairo_int64_t
det32_64 (int32_t a, int32_t b,
          int32_t c, int32_t d)
{
    /* det = a * d - b * c */
    return _cairo_int64_sub (_cairo_int32x32_64_mul (a, d),
                             _cairo_int32x32_64_mul (b, c));
}


static inline cairo_int128_t
det64x32_128 (cairo_int64_t a, int32_t       b,
              cairo_int64_t c, int32_t       d)
{
    /* det = a * d - b * c */
    return _cairo_int128_sub (_cairo_int64x32_128_mul (a, d),
                              _cairo_int64x32_128_mul (c, b)); 
}


/* Compute the intersection of two lines as defined by two edges. The
 * result is provided as a coordinate pair of 128-bit integers.
 *
 * Returns %CAIRO_BO_STATUS_INTERSECTION if there is an intersection or
 * %CAIRO_BO_STATUS_PARALLEL if the two lines are exactly parallel.
 */
static cairo_bool_t
intersect_lines (cairo_bo_edge_t                *a,
                 cairo_bo_edge_t                *b,
                 cairo_bo_intersect_point_t     *intersection)
{
    cairo_int64_t a_det, b_det;

    /* XXX: We're assuming here that dx and dy will still fit in 32
     * bits. That's not true in general as there could be overflow. We
     * should prevent that before the tessellation algorithm begins.
     * What we're doing to mitigate this is to perform clamping in
     * cairo_bo_tessellate_polygon().
     */
    int32_t dx1 = a->edge.line.p1.x - a->edge.line.p2.x;
    int32_t dy1 = a->edge.line.p1.y - a->edge.line.p2.y;

    int32_t dx2 = b->edge.line.p1.x - b->edge.line.p2.x;
    int32_t dy2 = b->edge.line.p1.y - b->edge.line.p2.y;

    cairo_int64_t den_det;
    cairo_int64_t R;
    cairo_quorem64_t qr;

    den_det = det32_64 (dx1, dy1, dx2, dy2);

         /* Q: Can we determine that the lines do not intersect (within range)
      * much more cheaply than computing the intersection point i.e. by
      * avoiding the division?
      *
      *   X = ax + t * adx = bx + s * bdx;
      *   Y = ay + t * ady = by + s * bdy;
      *   ∴ t * (ady*bdx - bdy*adx) = bdx * (by - ay) + bdy * (ax - bx)
      *   => t * L = R
      *
      * Therefore we can reject any intersection (under the criteria for
      * valid intersection events) if:
      *   L^R < 0 => t < 0, or
      *   L<R => t > 1
      *
      * (where top/bottom must at least extend to the line endpoints).
      *
      * A similar substitution can be performed for s, yielding:
      *   s * (ady*bdx - bdy*adx) = ady * (ax - bx) - adx * (ay - by)
      */
    R = det32_64 (dx2, dy2,
                  b->edge.line.p1.x - a->edge.line.p1.x,
                  b->edge.line.p1.y - a->edge.line.p1.y);

    if (_cairo_int64_negative (den_det)) {
        if (_cairo_int64_ge (den_det, R))
            return FALSE;
    } else {
        if (_cairo_int64_le (den_det, R))
            return FALSE;
    }

    R = det32_64 (dy1, dx1,
                  a->edge.line.p1.y - b->edge.line.p1.y,
                  a->edge.line.p1.x - b->edge.line.p1.x);
    if (_cairo_int64_negative (den_det)) {
        if (_cairo_int64_ge (den_det, R))
            return FALSE;
    } else {
        if (_cairo_int64_le (den_det, R))
            return FALSE;
    }

    /* We now know that the two lines should intersect within range. */

    a_det = det32_64 (a->edge.line.p1.x, a->edge.line.p1.y,
                      a->edge.line.p2.x, a->edge.line.p2.y);
    b_det = det32_64 (b->edge.line.p1.x, b->edge.line.p1.y,
                      b->edge.line.p2.x, b->edge.line.p2.y);

    /* x = det (a_det, dx1, b_det, dx2) / den_det */
    qr.quo = det32_64 (a_det, dx1,
                       b_det, dx2); //det64x32_128 (a_det, dx1, b_det, dx2);
    qr.rem = den_det;

    if (_cairo_int64_eq (qr.rem, den_det))
        return FALSE;
 
    intersection->x.exactness = EXACT;
    if (! _cairo_int64_is_zero (qr.rem)) {
        if (_cairo_int64_negative (den_det) ^ _cairo_int64_negative (qr.rem))
            qr.rem = _cairo_int64_negate (qr.rem);
        qr.rem = _cairo_int64_mul (qr.rem, _cairo_int32_to_int64 (2));
        if (_cairo_int64_ge (qr.rem, den_det)) {
            qr.quo = _cairo_int64_add (qr.quo,
                                       _cairo_int32_to_int64 (_cairo_int64_negative (qr.quo) ? -1 : 1));
        } else
            intersection->x.exactness = INEXACT; 
    } 

    intersection->x.ordinate = _cairo_int64_to_int32 (qr.quo);

    /* y = det (a_det, dy1, b_det, dy2) / den_det */
    /*qr.quo = det32_64 (a_det, dy1, b_det, dy2); //det64x32_128 (a_det, dy1, b_det, dy2);
    qr.rem = den_det;
    if (_cairo_int64_eq (qr.rem, den_det))
        return FALSE; */


} 

cairo_bool_t _cairo_bo_edge_intersect (cairo_bo_edge_t	*a,  cairo_bo_edge_t *b, cairo_bo_point32_t *intersection) {
    cairo_bo_intersect_point_t quorem;

    if (! intersect_lines (a, b, &quorem))
        return FALSE;
}

int main(int argc, char **argv)
  {
    return 0;
  }


