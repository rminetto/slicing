/* Statistics gathering tools. */
/* Last edited on 2016-04-21 14:22:03 by stolfilocal */

#ifndef raspol_stats_H
#define raspol_stats_H

#define _GNU_SOURCE
#include <stdio.h>

typedef struct raspol_stats_t
  { double tslice;  /* Slicing time (seconds). */
  } raspol_stats_t;
  /* Statistics about the slicing algorithm. */

void raspol_stats_clear(raspol_stats_t *st);
  /* Clears the statistics {st}. */

void raspol_stats_print(FILE *wr, raspol_stats_t *st);
  /* Prints the statistics {st} to {wr}. */

#endif
