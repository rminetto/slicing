/* See {raspol_stats.h}. */
/* Last edited on 2016-04-21 14:22:31 by stolfilocal */

#define _GNU_SOURCE
#include <stdio.h>

#include <raspol_stats.h>

void raspol_stats_clear(raspol_stats_t *st)
  { st->tslice = 0.0;
  }

void raspol_stats_print(FILE *wr, raspol_stats_t *st)
  { 
    fprintf(wr, "statistics: (TBW)\n");
  }
