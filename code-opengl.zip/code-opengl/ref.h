#ifndef ref_H
#define ref_H

/* Generic address type. */
/* Last edited on 2007-02-05 18:51:28 by stolfi */

typedef void *ref_t;

#endif
