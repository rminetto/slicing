/* See {salamic_stats.h}. */
/* Last edited on 2015-09-30 23:57:59 by stolfilocal */

#define _GNU_SOURCE
#include <stdio.h>

#include <salamic_stats.h>

void salamic_stats_clear(salamic_stats_t *st)
  { st->tslice = 0.0;
    st->tclose = 0.0;
  }

void salamic_stats_print(FILE *wr, salamic_stats_t *st)
  { 
    fprintf(wr, "statistics: (TBW)\n");
  }
