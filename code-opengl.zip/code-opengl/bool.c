/* See {bool.h} */
/* Last edited on 2007-01-03 23:41:18 by stolfi */

#include <bool.h>
