
ln -s ../../GENERIC.make
ln -s ../../GENERIC-PROGS-TEST.make
